# bariatricschistlukes
Bariatrics Website, CHI St. Lukes Health
